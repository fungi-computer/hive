# @fungi.computer/cairn

Cairn provides dependency-light, typed opaque identifiers and candidate word
names for Fungi packages. It has no Effect dependency or domain registry.

## Typed identifiers

```ts
import { defineIdFamily, type IdOf } from "@fungi.computer/cairn/id";

const machineIds = defineIdFamily({
  family: "machine",
  version: 1,
  kinds: {
    machine: { prefix: "machine" },
    lease: { prefix: "machine_lease" },
  },
});

type MachineId = IdOf<typeof machineIds.machine>;

const machineId: MachineId = machineIds.machine.generate();
const parsed = machineIds.machine.parse(machineId);

if (!parsed.ok) {
  throw new Error(`Invalid machine identifier: ${parsed.error.reason}`);
}
```

`defineIdFamily` creates one distinctly branded codec per caller-owned kind. New
identifiers use `<prefix>_<21 lowercase base36 characters>`. Parsing never
trims, case-folds, decodes, or normalizes input. An `acceptedSuffixLength` range
is only for a frozen compatibility grammar; generation remains 21 characters.

Cairn owns identifier grammar, secure generation, canonical parsing, and bounded
errors. The declaring domain owns its family and kind vocabulary, persistence,
uniqueness constraints, bounded collision retry, lifecycle, authorization, and
relationships. Relational or mutable facts do not belong in an identifier
string.

Zod 4.2.1 privately decodes family declarations and identifier wire values. A
narrow hostile-object membrane first snapshots only Cairn's fixed declaration
fields; Zod types, issues, and implementation paths do not enter the public
interface or errors.

Use the `./id` subpath when only identifier codecs are needed. The root exports
the same typed identifier API for convenience while preserving the existing raw
`nanoid` surface.

## Raw identifiers and candidate words

```ts
import { DEFAULT, SHORT, nanoid } from "@fungi.computer/cairn";
import { words } from "@fungi.computer/cairn/words";

const entityId = nanoid(DEFAULT);
const shortId = nanoid(SHORT);
const candidateName = words(); // e.g. `luminescent-morel`
```

The raw root `nanoid` export remains compatible and uses a lowercase
alphanumeric alphabet with a cryptographically secure random source. Its legacy
length coercion is retained: finite sizing values delegate exactly to the
runtime-selected upstream implementation and may be runtime-specific. Callers
should supply a bounded nonnegative integer unless they consciously accept
upstream/runtime-specific behavior. Only positive and negative infinity receive
Cairn's fixed bounded `RangeError`. `LONG` is a conventional 32-character size,
not an upper bound; callers may request other lengths. The export is retained
for existing callers; new durable domain identities should use a typed family
codec.

`words` uses rejection sampling over the exported vocabularies and does not
maintain a uniqueness registry. Callers choose `count` to size the candidate
entropy and may provide a custom separator. `words({ count })` retains its
legacy count coercion with no artificial upper cap, so count 9 is valid;
positive infinity fails with a bounded `RangeError`.

`nanoid(length)` and `words({ count })` treat their sizing parameters as trusted
sizing-policy inputs: CPU and output scale with the requested size or count.
Callers must parse and bound hostile values before entering these helpers. For
production durable identities, typed `defineIdFamily` is the bounded identity
seam.

The `./id` and `./words` entrypoints keep identity-only consumers separate from
the word corpus. Cairn's identifier contract is designed for the same observable
behavior in Node 24, browsers, and workerd/Workers runtimes.

## Third-party notice

Cairn's direct runtime dependencies are `nanoid` (5.1.16) and Zod (4.2.1).
Consult those dependencies' distributions for their license terms; this package
does not claim or reproduce third-party license text.

## License

MIT. See [LICENSE](./LICENSE).
