# Caps

Caps is Fungi's private, unreleased React UI foundation: reusable primitives and
product-neutral presentation blocks built on Daisy and Stipe. Use the workspace
package when a host wants the maintained runtime, or use the local registry
proof when a developer needs editable source.

Caps is not a runtime widget SDK. It does not fetch, navigate, perform checkout,
choose a model, or know a product's data model. The host owns state, effects,
copy, routes, and policy.

## Happy path

Import the exact subpath a host uses:

```tsx
import { Button } from "@fungi.computer/caps/components/button";
```

Caps deliberately has no root runtime export. Its component, block, utility, and
stylesheet subpaths are listed explicitly in `package.json`; that exports map is
the complete runtime address list. Do not add a barrel, alias, source-relative
consumer path, or hidden provider.

The checked-in registry is a separate editable-source workflow. Its generated
payloads are proved locally and install their files into an isolated fixture;
there is no public registry endpoint in this release candidate.

Both routes use the same foundation. Import Stipe once in the host (the registry
item also carries this CSS import):

```css
@import "@fungi.computer/stipe/styles.css";
```

## Button

The primitive keeps the native button contract. It forwards native props and the
ref, exposes `variant` and `size`, and merges the caller's class last.

```tsx
import { useRef } from "react";
import { Button } from "@fungi.computer/caps/components/button";

export function SaveButton({
  pending,
  onSave,
}: {
  pending: boolean;
  onSave: () => void;
}) {
  const ref = useRef<HTMLButtonElement>(null);

  return (
    <Button
      ref={ref}
      type="submit"
      aria-label="Save changes"
      disabled={pending}
      loading={pending}
      variant="outline"
      size="sm"
      className="transition-none rounded-full"
      onClick={onSave}
    >
      Save
    </Button>
  );
}
```

`className` is intentional here: the caller's `transition-none` replaces the
base transition utility, while `rounded-full` adds a local treatment. Daisy's
`btn-outline` and color classes are composable, so color belongs in `variant` or
as an additional Daisy class rather than being described as an override.

## Composer

`Composer` is a layout block. Its input and action are caller-owned controls; so
are their labels, disabled state, keyboard behavior, and effects. A host that
renders an avatar with Sprite passes that rendered React node through the action
slot; Caps does not adapt or depend on Sprite.

```tsx
import { FormEvent, useState } from "react";
import { Button } from "@fungi.computer/caps/components/button";
import { Composer } from "@fungi.computer/caps/blocks/composer";

export function PromptComposer({
  submit,
}: {
  submit: (value: string) => Promise<void>;
}) {
  const [value, setValue] = useState("");
  const [pending, setPending] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!value.trim() || pending) return;
    setPending(true);
    try {
      await submit(value);
      setValue("");
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={onSubmit}>
      <Composer
        input={
          <input
            className="input join-item w-full"
            value={value}
            onChange={(event) => setValue(event.target.value)}
            aria-label="Prompt"
          />
        }
        action={
          <Button
            type="submit"
            size="sm"
            disabled={pending || !value.trim()}
            loading={pending}
          >
            Send
          </Button>
        }
      />
    </form>
  );
}
```

There is no fake API in this example. `submit` is the host's effect: it may call
an API, enqueue work, or do something local. Caps only joins the controls.

## App bar

`AppBar` adapts the retained workbench toolbar presentation without importing a
window store or product catalog. The caller owns item identity, selected state,
and every action; Caps owns only responsive disclosure and native focus return.

```tsx
import { AppBar } from "@fungi.computer/caps/blocks/app-bar";

export function WorkbenchBar() {
  return (
    <AppBar
      items={[
        {
          id: "editor",
          label: "Editor",
          active: true,
          onSelect: () => openWindow("editor"),
        },
      ]}
      launcher={{ label: "Launch", onLaunch: openLauncher }}
      actions={[{ id: "settings", label: "Settings", onAction: openSettings }]}
    />
  );
}
```

Ordinary action buttons do not claim toggle state. At narrow widths the launcher
discloses one keyboard-navigable list; closing it with Escape returns focus to
the launcher.

## Dashboard presentation

`Status` uses Daisy's status-bead vocabulary. Keep durable readouts static and
choose bounce only for activity that is actually in progress. `IconButton`
defaults to the Dashboard's ghost, circular, extra-small control and supports
its responsive, active, revealed, and destructive states.

`RowBead` owns the retained gooey filter, dot, selected/hover pill, and
unread-bang transition after a host maps its product state to `tone`, `motion`,
`selected`, and `unread`. `Checkbox`, `Switch`, and `Progress` keep their native
elements and existing animations while sharing the bead’s highlight and shadow.
`ScrollToBottomBlob` observes a supplied column-reverse scroller and owns its
idle, wobbling, and shedding motion while the host owns the jump callback.

## Browse the workbench

Run `pnpm workbench:serve` from the repository root. Ladle opens on a visual
overview, followed by Foundations, Controls, Feedback, Compositions, and
Interactions. Each sample has a named story you can link to when reviewing what
to keep, change, or remove. Feedback → Row bead compares the bead, checkbox,
switch, and progress bar in Latte and Mocha. Compositions shows the pieces
assembled into larger examples.

## Themes and CSS

Stipe keeps Daisy's theme catalog open. Set any Daisy theme with `data-theme`;
`latte` and `mocha` are the maintained fungi presets.

```tsx
<html data-theme="mocha">
  <body>{children}</body>
</html>
```

Product CSS can add a preset or local treatment by overriding semantic Daisy or
Stipe variables. Keep it CSS-only:

```css
[data-theme="workbench"] {
  --color-primary: #8b5cf6;
  --color-primary-content: #ffffff;
  --stipe-surface: var(--color-base-200);
  --stipe-fg-muted: #4c4f69;
}
```

Use opaque semantic tokens for text hierarchy and ordinary surfaces. Reserve
opacity for genuine compositing, such as scrims, overlays, and visual effects.

Do not import Tailwind a second time or mirror Stipe's token sheet in the host.

## Rules for agents

- Inspect the existing source, tests, and host before editing.
- Preserve native semantics, refs, keyboard behavior, visible focus, and ARIA.
- Primitives and blocks receive props, slots, and callbacks; they do not fetch.
- Keep product vocabulary, models, routes, defaults, and side effects in hosts.
- Use explicit imports. Do not add a root barrel, alias, shim, or deprecated
  export.
- Add or update tests and an example for every new public seam.

## Add a registry item

Author the canonical source under `src/`, then add tests and an example. Add the
item metadata to `registry-source/` (including files, dependencies, registry
dependencies, and the Stipe CSS import). Generate the payloads, then run both
checks:

```sh
pnpm --filter @fungi.computer/caps registry:generate
pnpm --filter @fungi.computer/caps registry:check
pnpm --filter @fungi.computer/caps registry:stranger
```

Generation is the ownership boundary: `registry/` and `registry.json` are
derived artifacts. The registry stranger gate installs every generated item into
an isolated fixture, checks local imports and dependencies, type-checks it, and
builds it. It proves only that a local consumer can own the copied source
without a Caps runtime import.

## Verify the package

The current suite contains 15 component and block test files with 68 law cases.
It covers native props and refs, caller-last classes, labelled fields,
controlled values, focus and keyboard behavior, disabled options, Escape,
tooltip teardown, SSR, state blocks, upload-row presentation, and gooey-filter
identity.

Run the ordinary private-development checks from the repository root:

```sh
pnpm --dir packages/caps run lint
pnpm --dir packages/caps run typecheck
pnpm --dir packages/caps run test
pnpm --dir packages/caps run build
pnpm --dir packages/caps run docs
pnpm check:package -- @fungi.computer/caps
```

`pack`, `smoke`, the package-level `stranger`, and
`pnpm verify:package -- @fungi.computer/caps` are publication-only operations.
Do not run them during ordinary development. `registry:stranger` is the
different, required package-local editable-source proof.

## Ownership and non-goals

Caps owns reusable rendering plus interaction, controlled or uncontrolled state,
focus, keyboard handling, teardown, and accessibility intrinsic to a UI
primitive. Hosts own product data and state, authority, routes, persistence,
fetching, effects, commands, policy, and product copy. Caps does not implement
Dashboard or Parakeet behavior, publish a registry, deploy a site, or own a
product workflow.

## Verification note

The repository contains the workspace package, source, retained law tests,
generated registry payloads, and isolated local materialization proof. Caps
depends on the real `@fungi.computer/stipe` workspace package; copied styles or
an alias are not a valid substitute.

The retained manifest records MIT history, but the transferred tree contains no
`LICENSE`, `NOTICE`, or `CHANGELOG.md`. Do not fabricate those files or a
release claim. The missing license text blocks public editable-source delivery
and package publication; it does not block private implementation, local tests,
registry generation, or local materialization.
