# @fungi.computer/stipe

Stipe provides bounded Daisy theme composition and Fungi-only visual tokens,
terminal projections, Pierre tree styling, Gooey constants, and safe theme
observation.

## Install and import

```ts
import {
  applyTheme,
  getTheme,
  pierreTreesStyle,
  STIPE_GOOEY_FILTER,
  terminalPalette,
} from "@fungi.computer/stipe";
import "@fungi.computer/stipe/styles.css";
```

The package root is the public convenience surface. `./theme` and
`./pierre/trees` are the typed JavaScript subpaths; `./styles.css` and
`./pierre/trees.css` are the CSS entrypoints.

Coding agents can apply arbitrary Daisy theme names with `applyTheme`, read the
root theme with `getTheme`, and observe it safely in SSR contexts. Theme changes
emit no storage or global events. `terminalPalette` returns explicit absence for
unknown themes; Pierre and Gooey exports are bounded projections only. This
package has no publication or deployment authority; its build, documentation,
pack, smoke, and stranger gates remain separate operations.

## Ownership and absence

Stipe owns Daisy composition, Fungi-only visual tokens, and projections only.
Hosts own persistence, DOM application policy, storage, events, and product
components. Unsupported React, Dashboard, routing, state, command, copy, and
policy APIs are intentionally absent.

## License

MIT. See [LICENSE](./LICENSE).
