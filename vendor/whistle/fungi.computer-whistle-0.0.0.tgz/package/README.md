# @fungi.computer/whistle

Whistle is a dependency-free semantic command runtime. One typed command
definition derives six immutable views: binding, palette, slash, help, menu, and
agent. Eight closed origins—agent, browser, keyboard, menu, palette,
programmatic, slash, and terminal—enter one typed execution door. Contributions
are admitted atomically, and each contribution gets a generation-specific lease
whose disposal cannot remove a replacement. Snapshots and their rows are
immutable copies. Surface order is deterministic, including UTF-8 byte ordering
for ties.

This unreleased v0.0.1 candidate provides the semantic graph, typed contribution
seam, immutable snapshots, exact-generation disposal, and private finite
defensive bounds. The bounds are implementation defenses, not stable API
promises. A supplied handler is called only by `execute`; its returned data
travels in `handled.result`. `handled` means the handler finished, not that
physical work or a durable workflow completed. Missing commands, blank command
identities and handler failures return `missing`, `invalid` and `failed`.

Commands may supply a synchronous `availability()` reader over current host
facts. `snapshot()` preserves unavailable actions with their reason, and
`execute()` reads availability again before invoking the handler. Unchanged
availability retains snapshot identity. The host updates its own facts and
publishes snapshots through its existing connection; Whistle owns no polling or
broadcast transport. Availability is a convenience decision, not authorization;
the domain handler must still admit the actual request.

Failures carry JSON data: `{ code, message, details? }`. An owner may throw
`WhistleActionError` to supply its code and structured details. Ordinary errors
become `command_failed`; stacks and arbitrary thrown objects do not cross the
execution result. Input/output schemas describe structured data and keep opaque
JSON annotations. Local presentation hints may help a client, but a server
capability must not prescribe its form, menu or other rendering.
`presentation: { type: "custom", data }` can carry an owning client's field or
gesture bindings. Human projections preserve that opaque JSON; the Agent
projection excludes all presentation metadata and retains the semantic schemas.

Calling `close` is synchronous and idempotent and returns exactly `undefined`.
The first call releases every live contribution and retains the shared immutable
empty closed snapshot; repeated calls retain that snapshot, and already-issued
leases are harmless. An execution Promise returned before close remains
caller-observed and may settle `handled`; close neither cancels nor detaches it.
A later valid `execute` returns `closed`, while a later valid contribution
throws the narrow provisional `WhistleClosedError`.

Hosts retain parsing and physical matching, effects, rendering, and transport.
Whistle has no parser or transport. Hosts use maintained decoders for actual
untrusted input. A generic context language, subscriptions and notifications are
not implemented. Close has no asynchronous phase, cancellation, detachment,
tasks, timers, listeners, teardown system, or background work. Whistle owns no
browser, terminal, DOM, React, product, authorization, or durable-delivery
state.

## License

MIT. See [LICENSE](./LICENSE).
