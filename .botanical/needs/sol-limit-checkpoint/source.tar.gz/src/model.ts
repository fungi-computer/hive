// Domain values produced by our command UI and fixed-step simulation. Transport
// decoding belongs at a future persistence/network boundary, not in this model.
export type ActorId = string;
export type PartyId = string;
export type JobId = string;
declare const positiveIntBrand: unique symbol;
export type PositiveInt = number & { readonly [positiveIntBrand]: true };
export type LotId = string;
export type TransferId = string;
export type ContainerId = string;
export type OperationId = string;
/** Checked by the recipe definition owner; generic state carries an opaque ID. */
export type RecipeId = string;
/** Checked by the building/content definition owner for the resolved station. */
export type BrewStationSlot = string;
/** Pails are ordinary indivisible lots; water is always contained. */
export type Material =
  | "wood"
  | "mugwort"
  | "water"
  | "pail"
  | "malt"
  | "barm"
  | "keg"
  | "ale"
  | "spent-grain"
  | "soil"
  | "ration";
export type ItemLotLocation =
  | ({ kind: "ground" } & Cell)
  | { kind: "hand"; actor: ActorId }
  | { kind: "container"; container: ContainerId };
export type ItemLot = {
  id: LotId;
  material: Material;
  quantity: PositiveInt;
  location: ItemLotLocation;
};
export type SourcePolicy =
  | { readonly kind: "eligible-ground"; readonly material: Material }
  | {
      readonly kind: "eligible-container";
      readonly material: Material;
      readonly container: ContainerId;
    }
  | { readonly kind: "exact-lot"; readonly lot: LotId };
export type TransferOrigin =
  | { readonly kind: "ground"; readonly cell: Cell }
  | { readonly kind: "container"; readonly container: ContainerId };
export type TransferRequest = {
  readonly source: SourcePolicy;
  /** A whole request preserves one source lot; a portion may split it. */
  readonly quantityPolicy: "whole-lot" | "portion";
  readonly quantity: PositiveInt;
};
/** A held item is either promised to a container or retained for one operation. */
export type CarryIntent =
  | { readonly kind: "deliver"; readonly destination: ContainerId }
  | { readonly kind: "use"; readonly operation: OperationId };
export type JobTransferOwner = {
  readonly kind: "job";
  readonly job: JobId;
  readonly step: string;
};
export type OperationTransferOwner = {
  readonly kind: "operation";
  readonly operation: OperationId;
};
export type TransferOwner = JobTransferOwner | OperationTransferOwner;
/** Durable material promises outlive the worker currently moving a lot. */
export type MaterialBinding =
  | {
      readonly kind: "vessel-use";
      readonly id: OperationId;
      readonly vessel: LotId;
    }
  | {
      /** A non-container operation consumes this exact ordinary held lot. */
      readonly kind: "operation-use";
      readonly id: OperationId;
      readonly lot: LotId;
      readonly quantity: PositiveInt;
    }
  | {
      /** A resolved physical plan; recipe semantics stay with its definition. */
      readonly kind: "recipe";
      readonly id: OperationId;
      readonly definition: RecipeId;
      readonly station: ContainerId;
      readonly consumed: readonly {
        readonly role: string;
        readonly lot: LotId;
        readonly material: Material;
        readonly quantity: PositiveInt;
      }[];
      readonly retained: readonly {
        readonly role: string;
        readonly lot: LotId;
        readonly material: Material;
        readonly quantity: PositiveInt;
      }[];
      readonly promises: readonly {
        readonly role: string;
        readonly destination: ContainerId;
        readonly material: Material;
        readonly quantity: PositiveInt;
      }[];
    };
export type Transfer = {
  readonly id: TransferId;
  readonly actor: ActorId;
  /** Consumer-defined opaque identity; the material kernel never branches on it. */
  readonly owner: TransferOwner;
  readonly request: TransferRequest;
  readonly intent: CarryIntent;
  phase:
    | {
        kind: "reserved";
        sourceLot: LotId;
        quantity: PositiveInt;
        origin: TransferOrigin;
      }
    | { kind: "carrying"; lot: LotId };
};
export type EmbeddedMaterial = {
  container: ContainerId;
  material: Material;
  quantity: PositiveInt;
};
/** Immutable provenance and, after settlement, durable output receipt. */
export type RecipeTransformation = {
  readonly id: OperationId;
  readonly definition: RecipeId;
  readonly inputs: readonly {
    readonly role: string;
    readonly lot: LotId;
    readonly material: Material;
    readonly quantity: PositiveInt;
  }[];
  /** Null is an attended/fermenting transformation with its live binding. */
  readonly settlement: null | {
    readonly station: ContainerId;
    readonly retained: readonly {
      readonly role: string;
      readonly lot: LotId;
      readonly material: Material;
      readonly quantity: PositiveInt;
    }[];
    readonly outputs: readonly {
      readonly role: string;
      readonly destination: ContainerId;
      readonly material: Material;
      readonly quantity: PositiveInt;
    }[];
  };
};
/** A durable settled-output consumption; its physical lot may later be gone. */
export type RecipeConsumption = {
  readonly id: OperationId;
  readonly transformation: OperationId;
  readonly role: string;
  readonly material: Material;
  readonly quantity: PositiveInt;
};
/** Durable physical removal without creating a second inventory or event stream. */
export type MaterialSinkReceipt = {
  readonly id: string;
  readonly material: Material;
  readonly quantity: PositiveInt;
};
export type MaterialsState = {
  lots: ItemLot[];
  transfers: Transfer[];
  bindings: MaterialBinding[];
  transformations: RecipeTransformation[];
  consumptions: RecipeConsumption[];
  sinks: MaterialSinkReceipt[];
  embedded: EmbeddedMaterial[];
  nextLotId: number;
  consumedWood: number;
};
export type FeatureId = string;
export type SourceFeatureKind = "spring" | "reclaimed-timber-cache";
type SourceFeatureBase = Cell & {
  id: FeatureId;
  /** Access is metadata. Its finite quantity is a lot in sourceContainer(id). */
};
export type SourceFeature =
  | (SourceFeatureBase & { kind: "spring"; access: "open" })
  | (SourceFeatureBase & {
      kind: "reclaimed-timber-cache";
      access: "sealed";
      /** The once-only repair gate belongs only to the cache capability. */
      repaired: boolean;
    });
export type PendingFeatureIntroduction = {
  id: FeatureId;
  kind: SourceFeatureKind;
  preferred: Cell;
};
export type HerbId = string;
export type Cell = { x: number; z: number; level: number };
export type BuildingKind =
  | "wall"
  | "door"
  | "roof"
  | "bed"
  | "shelf"
  | "floor"
  | "stair"
  | "brew-station";
export type WorkType = "chop" | "haul" | "build" | "garden" | "craft";
export type AllowedWork = Record<WorkType, boolean>;
export type Scope = { party: PartyId; actors: ActorId[] | null };

export type WorkCommand = Scope & { direct?: boolean } & (
    | { kind: "chop"; tree: string }
    | ({ kind: "dig" | "backfill" } & Cell)
    | ({ kind: "build"; type: BuildingKind; direction: number } & Cell)
    | { kind: "deconstruct"; site: string }
    | ({ kind: "sow" } & Cell)
    | { kind: "harvest"; herb: HerbId }
    | { kind: "water-mugwort"; herb: HerbId }
    | { kind: "rest" }
  );
export type StoreCommand = {
  kind: "store";
  party: PartyId;
  actors: null;
  lot: LotId;
  shelf: string;
};
export type RepairCacheCommand = Scope & {
  kind: "repair-cache";
  direct?: boolean;
};
export type FillKettleCommand = Scope & {
  kind: "fill-kettle";
  direct?: boolean;
  station: string;
};
/** Recipe selection stays pinned in the process owner; the command names only its station. */
export type BrewCommand = Scope & {
  kind: "brew";
  direct?: boolean;
  station: string;
};
/** Tap chooses only a finished station; recipe receipt and serving stay owned below UI. */
export type TapCommand = Scope & {
  kind: "tap";
  direct?: boolean;
  station: string;
};
/** Station-owned output disposal; the recipe resolves the actual tray portion. */
export type ClearSpentGrainCommand = Scope & {
  kind: "clear-spent-grain";
  direct?: boolean;
  station: string;
};
export type Command =
  | WorkCommand
  | StoreCommand
  | RepairCacheCommand
  | FillKettleCommand
  | BrewCommand
  | TapCommand
  | ClearSpentGrainCommand
  | (Scope & { kind: "cancel" | "next"; job: JobId })
  | (Scope & { kind: "routine"; enabled: boolean })
  | (Scope & { kind: "work"; work: WorkType; enabled: boolean })
  | { kind: "draft"; party: PartyId; actor: ActorId }
  | { kind: "undraft"; party: PartyId; actor: ActorId }
  | { kind: "go"; party: PartyId; actor: ActorId; target: Cell }
  | { kind: "recruit"; party: PartyId; actor: ActorId };

type JobBase = {
  id: JobId;
  scope: Scope;
  reason: string;
  routine: boolean;
};
export type ChopJob = JobBase & { kind: "chop"; target: string };
export type BuildJob = JobBase & { kind: "build"; target: string };
export type DeconstructJob = JobBase & { kind: "deconstruct"; target: string };
export type SowJob = JobBase & { kind: "sow"; target: HerbId };
export type HarvestJob = JobBase & { kind: "harvest"; target: HerbId };
export type WaterMugwortJob = JobBase & {
  kind: "water-mugwort";
  target: HerbId;
};
export type StoreJob = JobBase & {
  kind: "store";
  source: LotId;
  destination: ContainerId;
};
/** Personal physical care is deliberately outside a work-party scope. */
export type CareNeed = "nourishment" | "hydration" | "rest";
export type CareJob = {
  id: JobId;
  kind: "care";
  target: ActorId;
  need: CareNeed;
  policy: "automatic" | "manual-rest" | "routine-rest";
  reason: string;
  routine: boolean;
};
export type RepairCacheJob = JobBase & {
  kind: "repair-cache";
  target: FeatureId;
};
export type FillKettleJob = JobBase & {
  kind: "fill-kettle";
  target: string;
};
export type BrewJob = JobBase & { kind: "brew"; target: string };
export type TapJob = JobBase & {
  kind: "tap";
  target: string;
  transformation: OperationId;
  progress: number;
};
export type ClearSpentGrainJob = JobBase & {
  kind: "clear-spent-grain";
  target: string;
  transformation: OperationId;
  progress: number;
};
export type DigJob = JobBase & {
  kind: "dig";
  x: number;
  z: number;
  level: 0;
};
export type BackfillJob = JobBase & {
  kind: "backfill";
  x: number;
  z: number;
  level: 0;
};
export type TerrainJob = DigJob | BackfillJob;
export type Job =
  | ChopJob
  | BuildJob
  | DeconstructJob
  | SowJob
  | HarvestJob
  | WaterMugwortJob
  | StoreJob
  | CareJob
  | RepairCacheJob
  | FillKettleJob
  | BrewJob
  | TapJob
  | ClearSpentGrainJob
  | TerrainJob;
export type Assignment = { character: ActorId; task: JobId; cost: number };
type ActivityBase = {
  job: JobId;
  target: string;
  duration: number;
};
export type ChopActivity = ActivityBase & { kind: "chop" };
export type BuildActivity = ActivityBase & { kind: "build" };
export type DeconstructActivity = ActivityBase & { kind: "deconstruct" };
export type SowActivity = ActivityBase & { kind: "sow" };
export type HarvestActivity = ActivityBase & { kind: "harvest" };
export type TransferActivity = ActivityBase & { kind: "transfer" };
export type SleepActivity = ActivityBase & { kind: "sleep" };
export type ConsumeActivity = ActivityBase & { kind: "consume" };
export type WaterDeliveryActivity = ActivityBase & { kind: "water-delivery" };
export type RepairCacheActivity = ActivityBase & { kind: "repair-cache" };
export type BrewActivity = ActivityBase & { kind: "brew" };
export type TapActivity = ActivityBase & { kind: "tap" };
export type ClearSpentGrainActivity = ActivityBase & {
  kind: "clear-spent-grain";
};
export type TerrainActivity =
  (ActivityBase & { kind: "dig" }) | (ActivityBase & { kind: "backfill" });
export type Activity =
  | ChopActivity
  | BuildActivity
  | DeconstructActivity
  | SowActivity
  | HarvestActivity
  | TransferActivity
  | SleepActivity
  | ConsumeActivity
  | WaterDeliveryActivity
  | RepairCacheActivity
  | BrewActivity
  | TapActivity
  | ClearSpentGrainActivity
  | TerrainActivity;
export type Body = Cell & {
  dir: number;
  mode: "idle" | "walk" | Activity["kind"];
  path: Cell[];
  leg: number;
  work: number;
};
export type Actor = Body & {
  id: ActorId;
  name: string;
  figure: string;
  drafted: boolean;
  needs: Needs;
  routine: boolean;
  allowedWork: AllowedWork;
  task: Activity | null;
  assignment: Assignment | null;
};
export type Tree = Cell & { id: string; work: number; felledAt: number | null };
export type HerbStage = "ordered" | "planted" | "growing" | "ready";
export type Herb = Cell & {
  id: HerbId;
  kind: "mugwort";
  stage: HerbStage;
  work: number;
  /** The one establishment fact carries either verified water or legacy trajectory. */
  establishment:
    | null
    | { readonly kind: "legacy"; readonly at: number }
    | { readonly kind: "water"; readonly at: number; readonly receipt: string };
  plantedAt: number | null;
};
export type Site = Cell & {
  id: string;
  type: BuildingKind;
  direction: number;
  work: number;
  finishedAt: number | null;
};
export type StoryEvent = {
  kind: string;
  name: string;
  tick: number;
  text: string;
};
/** Semantic completion belongs to the checked water-delivery target resolver. */
export type WaterDeliveryTarget =
  | { readonly kind: "kettle"; readonly station: string }
  | { readonly kind: "mugwort"; readonly herb: HerbId }
  | { readonly kind: "hydration"; readonly actor: ActorId };
/** One saved pail/water operation, independent of its current executor. */
export type WaterDeliveryOperation = {
  kind: "water-delivery";
  id: OperationId;
  job: JobId;
  spring: FeatureId;
  target: WaterDeliveryTarget;
  quantity: PositiveInt;
  pail: LotId;
  water: LotId | null;
  /** Incomplete effect phase; successful pour retires this operation. */
  phase: "acquire" | "draw" | "pour";
};
/** A ration is carried by the ordinary operation-owned use transfer. */
export type ConsumeOperation = {
  kind: "consume";
  id: OperationId;
  job: JobId;
  actor: ActorId;
  definition: string;
};
export type CareOutcome = {
  id: string;
  receipt: string;
  actor: ActorId;
  need: "nourishment" | "hydration";
  definition: string;
  amount: number;
  tick: number;
};
export type Needs = {
  advancedAt: number;
  nourishment: number;
  hydration: number;
  rest: number;
};
/** The process owner advances this one saved process; workers attend PREPARE/KEG. */
export type BrewProcess = {
  id: OperationId;
  job: JobId;
  station: string;
  binding: OperationId;
  phase: "prepare" | "ferment" | "keg";
  progress: number;
  enteredAt: number;
};
export type TerrainEdit = { x: number; z: number; level: 0 };
export type TerrainState = {
  base: "authored-clearing-v1";
  edits: TerrainEdit[];
  revision: number;
};
export type Clearing = {
  seed: number;
  tick: number;
  paused: boolean;
  nextId: number;
  actors: Record<ActorId, Actor>;
  parties: Record<PartyId, { id: PartyId; members: ActorId[] }>;
  cat: Body & { nextMove: number };
  trees: Tree[];
  herbs: Herb[];
  materials: MaterialsState;
  sources: SourceFeature[];
  pendingSources: PendingFeatureIntroduction[];
  operations: (WaterDeliveryOperation | ConsumeOperation)[];
  careOutcomes: CareOutcome[];
  processes: BrewProcess[];
  terrain: TerrainState;
  rocks: Cell[];
  watcher: Cell;
  sites: Site[];
  // This ordered array remains the sole job store. Priority is its order; an
  // additional mutable status/index store would add no needed behavior here.
  jobs: Job[];
  workDirty: boolean;
  felled: number;
  finishedJobs: number;
  harvestedHerbs: number;
  commands: (Command & { tick: number })[];
  feed: {
    seed: number;
    sequence: number;
    nextAt: number;
    last: StoryEvent | null;
  };
  demand: StoryEvent | null;
  notice: string;
};
export type Colony = {
  compute_cost(input: {
    travel_time: number;
    work_time: number;
    priority: number;
  }): number;
  optimize(assignments: Assignment[]): Assignment[];
};
