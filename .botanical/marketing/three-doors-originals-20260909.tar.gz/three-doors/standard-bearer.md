# Meter Kings Standard-Bearer — the bill a stranger reads at each door

**Date:** 2026-08-22 · **Persona stance:** conformance + honesty. The meter's engine is the
CounterRegistry (the kings' A–F); the STANDARD-BEARER guards the FACING: what a stranger pulls
up in their first ten minutes at each of the three doors, and whether the money is honest.
**Method:** memo.md + metering-pricing.md + port-maps/platform-bleed-audit.md (K1–K15, ARCH-134)

- metering-inventory.md read; all verified cost figures cited from those. READ-ONLY.

## §0 The honest-moneys bar (the README sentence — LAW of the facing)

> **"We charge for what we spend, and we mark it up honestly."**

Three "nevers", one proof, enforced at every door:

1. **Never bill what you can't measure.** A line on a bill requires a counter that (a) is
   measured in-worker at settle, or (b) has passed the reconciliation gate (§5). Rates-only
   legs (CPU-ms, R2 usage, GB-s duration, egress) are _informational_ meters until gate-verified —
   surfaced, never billed unseen.
2. **Never hide a markup.** Every line carries its rate-card cost and the markup as two numbers,
   or one combined number with an explicit "incl. 25% platform fee". No undifferentiated bucket.
3. **Never hide a leak as a feature.** Wedge-law disciplines OUR unmetered leaks; a user's
   deliberate choice (keep-warm, always-on) is a billable tier with a visible line (§6).
4. **Proof:** reconciliation of our computed basis vs CF Billable Usage / FOCUS (§5). A drift is
   OUR bug — we refund overcharges, we never "find" money.

## §1 The three doors — who pays, what a stranger SEES (LAW)

| Door              | Pays for           | The ten-minute read on the bill                                                                                                                                                | Meter class                                |
| ----------------- | ------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------ |
| **1 Normies**     | outcomes           | Credits, not meters. A pack "$10 = 200 credits", a per-generation feel ("this video cost 12 credits"), balance left. NO CPU/DO/storage lines, ever                             | credit packs (chargeUnits / media per-gen) |
| **2 Businesses**  | the machine        | Per-tenant meters on their corner: turns, channels, storage, **the always-on tier as an explicit plan line** — each meter = count × unit price, rate-card link on every line   | metered machine counters                   |
| **3 Vibe-coders** | the platform rails | Model spend = **$0.00 passthrough, billed by their provider (BYO never metered, LAW)**. Then rail lines: dynamic-worker runs, sandbox hours, memory-as-artifact, kept projects | platform-cut rail meters                   |

The lean (industry steal, in house dialect): Stripe-metered grammar under the hood (usage events →
meters → periods → dunning); credits at the normie door (Suno/Midjourney read); per-1M one-key
sheets and a supply-bazaar cut at the vibe-coder door (OpenRouter/RunPod read). One engine, three
readings. Nobody reads a counter they don't pay.

### Door 1 — normie (media class, ten minutes)

Buys a pack; generates; bill = pack + generations + leftover, all in credits.
**Honesty read:** the pack's credit value maps 1:1 to the public rate card in plain language
("one 720p 5s video ≈ $1.16 ≈ 12 credits"). Pre-flight estimate before every generation (media
pre-call balance exists in code, M1), settle actuals, never a surprise. **Gate:** media
`chargeUnits × 1.25` must LAND before launch — today image_generate burns Workers AI unmetered
behind a soft check (D5). An unmetered burn at the normie door is the honesty bar broken twice.

### Door 2 — business (ten minutes)

Sees count × rate on their corner: agent turns, channels, storage, W2 warm windows.
**Honesty read:** platform legs are itemized at honest rates × 1.25 with an explicit markup line;
keep-warm is never hidden inside "idle" — it is the always-on tier (§6), priced predictably as a
plan line. The bill can show what we measured because the drawer's cost settles at turn records
(model + platform, one ledger).

### Door 3 — vibe-coder (ten minutes)

Sees a zero next to models and real lines for rails: dynamic-worker runs (per RUN — two loader
legs F1+F2), sandbox hours, kept projects, channels, memory-as-artifact storage.
**Honesty read:** BYO rows never hit tryDeduct (LAW, already in code); no hidden 5% — BYOK has no
credit-purchase fee, and where Unified Billing's 5% exists it's a surfaced line, never absorbed
into "platform fees". The platform cut is four rails, each with a rate-card link.

## §2 Who pays at which door — the map (kings' ask, written as LAW)

- Normies → outcomes, pre-paid, stop-at-zero (never real-money debt).
- Businesses → the machine, post-paid, reconciled, always-on is a named tier.
- Vibe-coders → the rails, post-paid per-1M/per-run, models $0 by law.
- Our own surfaces (shiit.app/jamstack, P2-hosted) sit in the reconciliation base too — the meter
  never assumes "ours" is free (the drift hunt chases ghosts otherwise).

## §3 CounterRegistry as billing surface (A–C rulings)

**A. Shape — two layers.** Measurement registry: one counter per cost flow (islands: isolatesStarted
per RUN incl. the tool-package loader leg F2, per-gen, doRequests/dbBytes/rowWrites, r2Bytes+classOps,
warmWindowMs, + rate-gap counters Workflows/D1/KV/Artifacts, all starting informational). Billing
view: per door, ≤6 lines. Counters map onto exactly one door-visible line; the existing rails
(chargeUnits, media per-gen, metered_inference) are counters, not a parallel system.

**B. Attribution — one billing account per counter.** Boundary stamps keySource + per-key-owner rows
(exist). Sandbox/warm windows: per-TEAM at the business door (the tenant pays), per-SESSION only
when credit-backed. Rule: no orphan burn — the reconciliation hunt is BY DEFINITION un-attributed cost.

**C. Settle legs — billable = measurable.** Turn record cost already settles (model at meter close,
S14). Append platform leg = rates × OUR measured counts, measurable in-worker: tokens, media
per-gen, DO storage via databaseSize, DO requests, isolate starts, session/keep-warm windows.
Rates-only (CPU-ms, R2, GB-s duration, egress) join billing only after gate (§5); until then they
render on the business bill as "platform usage (included)" — informative, not billed.

## §4 Rate card + markup (D) — one honest table, one honest multiplier

- One auditable rate card (metering-pricing.md #1–10 + the 4 gaps priced) is the single source of
  truth every door's lines resolve to.
- ONE platform markup across all doors: ×1.25, always shown (existing MARKUP_MULTIPLIER is the
  precedent, not the exception). Normies see it inside the pack value ("incl. 25% platform fee");
  businesses and vibe-coders see it as a per-line markup or "incl." note. No silent per-door pricing.
- Media keeps chargeUnits × 1.25 on the gateway rail; BYOK media = their credits, passthrough.

## §5 Reconciliation + free-tier posture (E)

- **Cadence:** nightly FOCUS pull vs our daily settle rollup; the monthly bill IS the reconciled
  number. **Drift ownership: us, always.**
- **Free tier per door:** normie — credits-backing only, stop at zero, never bill arrears;
  business — trial meters soft-capped (80% warn, 100% hold), always-on unlocked by the tier;
  vibe-coder — BYOK models unmetered by law, rails included to a small threshold then metered with
  pre-flight estimate + warn; no silent cutoffs.
- PITR is $0 today (#8) — if enabled later it's a storage line, never folded into "database".

## §6 The always-on tier (F) — where it reads

- Mechanism: warmWindowMs per key-owner (W2 isolated-stable is keep-warm BY DESIGN) — the meter
  SURFACES warm windows; wedge-law/zero-candidate disarm stays our own leak-policing (W3), never
  applied to a user choice.
- Price: a fixed monthly plan line at the business door ("Always-On: 1 agent 24/7 = $X/mo"),
  computed from the honest keep-warm rate, itemized with a warm-uptime meter. Predictable, named,
  never a per-10ms surprise and never a hidden leak (LAW).
- Projects keep-warm? **No.** Kill-list law: projects are dynamic workers only — a warm project is
  a warm dynamic worker, billed inside the tenant's Always-On line, never a container.

## §7 The kill list is billing law too

The std-4 container-project class (~$289/mo warm — the most expensive unit on the platform) is
DEAD by ARCH-134/K1–K15. The meter therefore has NO counter for the dead class; containerWake
applies only to the sandbox product. K1/K3/K10 walking-dead surfaces are simultaneously an
ARCH-134 violation and an unmetered leak — one fix, and the honest-moneys bar is what makes both
enforceable: a surface we can't measure honestly must not exist on any bill.

FINAL: the meter must never be visible to anyone who doesn't pay for what it counts, must always
show the markup it takes, and must prove what it bills against CF's own books — one CounterRegistry,
three truthful doors, one README sentence.
