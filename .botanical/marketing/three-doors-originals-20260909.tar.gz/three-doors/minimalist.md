# METER KINGS — MINIMALIST POSITION (v2, grounded 2026-08-22)

Persona: MINIMALIST · Council doc `minimalist.md` · READ-ONLY (no edits to any other file)

## 0. SOURCES — VERIFIED ON DISK (2026-08-22)

- Read at repo root /Users/levi/Documents/Botanical/plans/: meter-kings/memo.md (three doors,
  kill list LAW), metering-pricing.md (unit rates), port-maps/platform-bleed-audit.md (P1-P3,
  K1-K15), metering-inventory.md (10 cost centers + bleed shapes). v1's `[?]` cells are now
  grounded from the real numbers — no guesses remain anywhere in this file.

## 1. THE LAW (memo — non-negotiable)

- THREE DOORS: (1) normies pay outcome-tiers/credits (media per-gen class); (2) businesses pay
  per-tenant meters, always-on tier, channels, storage; (3) BYOK/dev folk are NEVER metered on
  models — we earn on the PLATFORM rails (dynamic workers, sandbox hours, kept projects).
- CHARGE GATE: invoice identity = fungi-account or BYOK-bearer ONLY. BYO always `billable=false`.
- SOURCE GATE: every billed line traces to a real cost (pricing + bleed audit + inventory).
- keep-warm / always-on = BILLABLE TIER, never a hidden leak (P3 = charge, don't stop).
  Wedge-law (W3, already in code) applies ONLY to OUR unmetered leaks, never user choices.
- KILL LIST IS LAW: projects = DYNAMIC WORKERS ONLY. The std-4 container project class
  (~$289/mo: 4·86400·2e-5 + 12·86400·2.5e-6 + 20·86400·7e-8 ≈ $9.6/day) is DEAD (K1-K15).

## 2. THE SMALLEST HONEST METER — v1

3 new counters + 2 existing rails + settle-time legs. Everything else = line rate or cut.

### 2.1 Counters that EARN a counter in v1 (memo A)

| #   | Counter                          | Ground (verified)                                                                                                                  | Rate basis                                                                                     |
| --- | -------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| 1   | isolatesPerRun                   | P1 codemode = dynamic worker PER run; F1 execute + F2 tool-package invoke each boot a LOADER isolate — never drowned in "requests" | req countable in-worker; CPU-ms rates-only (Workers $5/mo min, $0.30/M req, $0.02/M CPU-ms)    |
| 2   | projectRuntime per project       | P2 after kill list: each project = its OWN dynamic worker (isolate req/CPU + R2 bundle bytes + TeamStorageDO row)                  | Workers $0.30/M req; R2 $0.015/GB-mo Std + Class A $4.50/M                                     |
| 3   | warmWindowMs per key-owner       | P3 keep-warm = billable tier; W2 isolated-stable + deliberate keep-alive = always-on tier                                          | Containers per-10ms: CPU $0.000020/vCPU-sec, mem $0.0000025/GiB-sec, disk $0.00000007/GB-sec   |
| 4   | mediaPerGen (existing rail)      | M1 single per-generation counter; chargeUnits x1.25 is ABSENT @ billing HEAD — wiring it is v1 work, not a new counter             | gpt-image-2 $5/$30 per 1M; seedance-2.5 720p $0.2312/s, 480p $0.1028/s (5s ≈ $1.16, 30s ≈ $29) |
| 5   | meteredInference (existing rail) | fungi-tier tokens = chargeUnits x1.25                                                                                              | deepseek-v4-flash $0.44/$1.32 per 1M; kimi-k2.7-code $0.95/$4.00                               |

- Workflows/D1/KV/Artifacts: RATE GAPS → line rates, NO counters. Per-op metering costs more to
  build AND audit than it protects at v1 scale. D1 IS live ($0.75/GB-mo STORAGE_DB) but tiny → line.

### 2.2 Platform leg — settle-time, NOT a flat per-fork price

- DRAWER'S COST = model + platform, appended at turn/claim/media settle (memo C).
- In-worker countable legs: tokens, per-gen, DO storage via sql.databaseSize ($0.20/GB-mo;
  rows-written $1.00/M; reqs $0.15/M), isolate starts, session windows (we own start/stop).
- Rates-only legs (UsageSummary/Logpush at settle): CPU-ms, R2 usage, DO GB-s $12.50/M, egress
  (Workers/R2 egress FREE; container egress $0.025/GB NA/EU, 1TB incl). Flat per-fork invoice
  line CUT — a single multiplier the customer can't verify is not honest metering (Door 2).

## 3. MINIMUM ATTRIBUTION (memo B)

- YES: per-key-owner + team is ENOUGH. Meter row = (keySource, keyOwnerId, teamId,
  billingAccountId, counter, ts, billable) — seven fields, whole schema.
- Sandbox/session windows attributed per SESSION (smallest unit an owner starts), rolled to team.
  BYO rows stamped `billable=false` — attributed for the drawer's visibility, never charged.
- CUT dims v1: per-fork breakdown, per-op, per-region, API-call granularity — all enrichment.

## 4. THE CUT LIST — bleed shapes get a LINE RATE, not a counter

| Bleed shape                                      | Line rate (grounded)                                                                                                                   |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------- |
| Idle compute (unlinked workers/isolates)         | Workers $5/mo min + $0.30/M req + $0.02/M CPU-ms extra                                                                                 |
| Orphaned storage (detached artifacts/registries) | R2 $0.015/GB-mo + DO SQLite $0.20/GB-mo + D1 $0.75/GB-mo + ops (A $4.50/M, B $0.36/M, rows-written $1.00/M)                            |
| Network                                          | container egress $0.025/GB (1TB mo incl); Workers/R2 egress $0 — line is $0 by design                                                  |
| AI passthrough (third-party; never a counter)    | gateway pass-through at cost: seedance 720p $0.2312/s; gpt-image-2 $5/$30 per 1M (+5% Unified Billing only on credit top-ups; BYOK 0%) |
| PITR                                             | $0 today (D7: no config in any wrangler.jsonc); if enabled = $0.20/GB-mo storage, still a line                                         |
| Unknown/new bleed shape                          | DEFAULT: fold into platform settle leg (2.2)                                                                                           |

- GUARDRAIL: any single bleed shape > 5% of monthly invoice value for 2 consecutive months
  EARNS a counter. Cut never means unaccounted — "line rate now, counter when it's real money."

## 5. v1 METER — THE WHOLE SHAPE (final)

1. Events: isolatesPerRun, projectRuntime, warmWindowMs, mediaPerGen, meteredInference.
2. Settle legs: rates × our measured counts (databaseSize, CPU-ms, usage) appended to turn records.
3. Sessions: per-session windows (we own start/stop); reduce warm cost by hibernation (sleeps to zero).
4. Always-on tier (memo F): mechanism = W2 isolated-stable + deliberate keep-warm; price =
   warmWindowMs × Containers per-10ms × 1.25. Projects can't hold a container warm after the
   kill list — only sandbox product + the always-on tier ever burn container time.
5. Invoice (per key-owner): model, media, platform (isolates+projects+sandbox), always-on, bleed lines.
6. Reconciliation (memo E): monthly diff vs FOCUS Billable-Usage API account totals; drift owner =
   billing persona; free tiers (10k neurons/day, 10M req, 10GB R2, 5GB DO) absorbed into the
   platform baseline — never surfaced as lines.

## 6. DOORS CHECK

- Door 1 ✓ every line names a key-owner identity. Door 2 ✓ 3 counters + settle legs trace to
  registry/timer logs + the cost docs. Door 3 ✓ BYO $0; keep-warm billed (never stopped).
- Normie door ✓ credits + media per-gen. Simplicity ✓ 5 counters, 1 rate card, 1 schema.

## 7. DISPOSITION

- Adopt §5. Kill list is LAW: projects = dynamic workers only — strike the $289/mo class from the
  rate card (K1-K15). Wire media chargeUnits x1.25 at billing HEAD (bleed M1 — media burns
  unmetered at product level today). All rates per metering-pricing.md 2026-08-22.

— end — 3 new counters, 2 existing rails, settle legs, zero guesses: the smallest honest meter is grounded now.
