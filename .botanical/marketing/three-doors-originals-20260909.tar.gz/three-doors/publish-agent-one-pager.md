# Publish-Agent — the second/third-door offer (Q3 OSS lane, one-pager)

Status: Q3 lane. Depends on: pass-3 `shiitake({opts})` constructor (landed `fb466800`), adoption
(`48ea856a`), seam pass v0.2 (`3dee2d26`) + the cutover (in-flight next), the bundling story.
Mechanism adopted, not built: Cloudflare for Platforms (Workers-for-Platforms: dispatch
namespaces, dynamic dispatch workers, per-tenant tags/bindings/custom-limits, trusted/untrusted
isolation, outbound-workers, per-tenant observability + usage billing).

## THE THREE DOORS (one platform, stacked)

| Door | Who                | They ship                                      | Model                                                                                                                  |
| ---- | ------------------ | ---------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| 1    | Normies (openclaw) | zero code, knobs only                          | consumer agent OS                                                                                                      |
| 2    | Businesses         | our agent + config (tools/keys/model/bindings) | "ready-to-deploy agent for your business" — the cheap second offer                                                     |
| 3    | Vibe-coders/devs   | their OWN agent code                           | untrusted mode on OUR namespace (Vercel-style: publish to us, we route/bill) + BYOK-account path for real code-writers |

All three ride the SAME rails: our CF-for-Platforms namespace + dispatch routing + per-tenant
tags/bindings/limits + the `shiit publish agent` CLI + per-tenant billing through our ledger.

## Door 3 specifics (untrusted customer code)

- WfP untrusted isolation ON (sandboxed) + outbound-workers = the egress bouncer (gate what
  customer code can reach; same instinct as no-creds-in-container).
- The DX wedge ("too silly to use CF directly"): `shiitake new` → `shiit publish` → live with
  billing wired, BYOK keys via the connections layer, per-tenant dashboard. Replaces raw CF
  namespace wrangling.
- The take: their agent's usage billed through our tenant ledger (Vercel-cousin fee).
- DO NOT build platform: adopt CF's; the novelty = packaging + per-tenant routing + billing.

## Sizing (measured, 2026-08-21)

- Core = `shiit publish agent` CLI (~200-300 ln) + the bundler (constructor+tools/extensions
  +model+bindings → worker, ~400-600) + per-tenant dispatch/label wiring (~150-250) + tests/docs
  (~200-400) ≈ 1,000-1,500 ln ≈ ONE gated rabbit pass.
- Wall ≈ 1.5-2 days (code ~1 day + namespace/infra/secrets friction ~0.5-1).
- Door 3 delta over door 2: posture + trust (untrusted mode, outbound gates) + arbitrary-code
  bundling path in the CLI — NOT new platform.

## Sequencing & laws

- Behind the cutover + bundling decision. OSS lane (CLI + scaffolder) = Q3.
- Laws: everything public (no privileged publish paths); BYOK account = a `--target` flag;
  defaults ship in the framework; secrets product-side (byok-cache pattern).

## DOOR-2 CORRECTION (Levi 08-21)

BYOK keys/models ALREADY exist platform-wide via the connections layer - NOT a door-2 differentiator.
Door 2 buys: per-tenant isolation/tenant boundary + an INDEPENDENT deployed surface (own routes,
not bolted to the main app) + their brand/channels + their control panel (config, not shared
product defaults). Multi-tenancy is the mechanism; the purchase is the corner.
