---
title: "fungi.computer Platform Sales Lines"
description: "Quote bank for fungi, Shiitake, Celld, Hypha, Computer, and the three-door deployment story."
tags: [fungi-computer, marketing, positioning, sales, celld, hypha, three-doors]
created: 2026-08-27
updated: 2026-08-27
---

# fungi.computer Platform Sales Lines

Sales language produced during the Celld evaluation and three-door discussion. Preserve the short
lines here even when a campaign ultimately chooses different copy.

## Category

> The Cloudflare of agents.

> The open agent cloud.

> One agent platform. Three doors.

> One platform for every agent, every app, and every computer.

> The operating system for companies run by agents.

> Agents, apps, and computers—one durable operating system.

## Portability and Deployment

> Write once for fungi. Deploy to the shared Cloudflare edge, a dedicated Celld fleet, or your own
> cloud. Attach computers anywhere through Hypha.

> Build once. Run on Cloudflare. Run on Celld. Attach computers anywhere.

> Turn your cloud into an agent cloud.

> Run the agent cloud in your cloud.

> You own the cloud. We bring the agent platform.

> Cloudflare-grade public hosting. Dedicated-cloud economics.

> Shared when you want it. Dedicated when it matters. Portable when you need it.

## Enterprise Economics

> The agent platform that runs in your cloud for roughly infrastructure cost—not per-request
> platform rent.

> Move your AI workforce off per-request rent.

> Your AI workforce should not have a landlord.

> AI infrastructure without the AI infrastructure tax.

> Cloud economics without cloud lock-in.

> Cloudflare-grade public hosting and dramatically better enterprise economics.

## Product Contrast

> Think competes with Shiitake, not with fungi.computer.

> Think is an ingredient. fungi.computer is the operating platform.

> Deploy an AI company, not another chatbot.

> A better Think. A better Cloudflare OS. At or below Cloudflare prices.

The final line is the founder's campaign thesis. It is the sharpest summary of the desired market
reaction, but its price claim remains a benchmark target rather than approved factual copy.

## Longer Pitch

> fungi.computer is the full platform: durable agents, sessions, branching, channels, apps, tools,
> Computer, Hypha, teams, billing, and three deployment doors. Shiitake is the portable agent
> runtime underneath it. Cloudflare runs the shared public cloud; Celld gives each enterprise a
> dedicated cloud at infrastructure economics; Hypha connects the computers where work actually
> happens.

> We only pay the Workers for Platforms isolation premium where strangers publish hostile code into
> our shared cloud. Enterprise customers get a dedicated Celld fleet in their trust domain, with
> Hypha connecting their own machines. Same platform and public APIs; radically different economics.

## Claim Guardrails

- **Use now:** the three-door, portability, category, and dedicated-versus-shared language.
- **Benchmark first:** “roughly infrastructure cost,” “at or below Cloudflare prices,” and any exact
  savings percentage.
- **Conformance first:** claiming the same application runs unchanged on Cloudflare and Celld.
- **Do not imply:** that Celld currently replaces Workers for Platforms for shared hostile
  multi-tenancy. The near-term Celld offer is one customer/application trust domain per fleet.
- **Do not collapse the products:** Workers for Platforms is Door 3's shared hostile-code rail;
  Celld is Door 2's dedicated enterprise rail; Hypha is the portable machine-execution rail.

## Related

- [[3-resources/case-studies/fungi-computer-platform|Case Study: fungi.computer]]
- [[1-projects/now/SALES-001-rework-consulting-offerings|SALES-001: Consulting Repositioning]]
- [[3-resources/jamstack-brand-voice|Jamstack Brand Voice]]
