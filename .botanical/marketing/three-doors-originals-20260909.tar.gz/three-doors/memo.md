# Three-Kings Memo — THE METER (price patterns, every burn, three doors)

## The question

Design the deep-meter module: one CounterRegistry pricing EVERY cost flow on the platform
(units + bleed shapes), attributed per key-owner/team, with settle-time cost legs, an honest rate
card, and reconciliation against CF's account truth (Billable Usage API / FOCUS). The kings price
PATTERNS, not just units, and map **who pays at which door**.

## THE THREE DOORS (LAW — the meter must serve all three)

1. **Normies** — pay outcome-tiers/credits (credit packs, per-generation feel — the media class).
2. **Businesses** — the deployed agent: per-tenant meters on their corner, the always-on tier,
   channels, storage — they pay for the machine.
3. **Vibe-coders/devs** — BYOK/BYO-subscriptions: we never meter their models (LAW); we earn on
   the PLATFORM rails — dynamic workers, memory-as-artifact, channels, sandbox hours, kept projects.

## The cost truth (read all — this is the ground)

- `plans/metering-pricing.md` — the UNIT rates (Workers AI per-1M: deepseek-v4-flash 0.44/1.32,
  kimi-k2.7 0.95/4.00; media per-gen: seedance 0.2312/s 720p default, gpt-image-2 5-30/1M; sandbox
  per-10ms; R2; DO SQLite 0.20/GB-mo; egress; free tiers).
- `plans/port-maps/platform-bleed-audit.md` — the BLEED map + CONTAINER-PROJECT KILL LIST (K1-K15,
  ARCH-134-proven): projects = DYNAMIC WORKERS ONLY (loader-isolate + R2 bytes + one row ≈ cheap;
  the old std-4 container project class ≈ 289/mo — DEAD by list).
- `plans/metering-inventory.md` — the inventory + BLEED SHAPES: P1 codemode = dynamic worker PER
  RUN (two loader legs); P2 user projects ride dynamic workers (cheap now); P3 keep-warm = CHARGE
  not stop (always-on = billable warm window; wedge-law discipline only for OUR unmetered leaks).
- 14 surfaces swept: media legs (per-gen + outputs R2 + MediaDO compute + Workflows = rate GAP),
  un-inventoried DOs (CodemodeRuntime/BrowserHost/ArtifactsMint/LocalWorkspace), rate-card gaps
  (Workflows/D1/KV/Artifacts).
- Industry pattern (context): Stripe-metered grammar (usage events → meters → periods → dunning);
  per-credits (Suno/Midjourney/Higgsfield); per-1M one-key sheets (OpenRouter); supply bazaar cut
  (RunPod/Replicate). Our lean = the Stripe-metered grammar + credits at the normie door +
  platform-cut meters for BYOK people.

## LAWS (do not redesign)

- charge = fungi/BYOK ONLY; **BYO never metered** (their models ride their account; we earn on rails).
- Engine-blind: the framework exposes cost at settle (turn records) — the METER is product/billing.
- The wedge-law discipline applies to OUR unmetered leaks, never user choices.
- Always-on/keep-warm = a billable tier, never a hidden leak.

## Open design surface (the kings' question A-F)

A. CounterRegistry shape: one counter per cost flow (units + shapes), the existing rails
(chargeUnits, media per-gen, metered_inference) as counters, new ones (isolate-per-run, project
R2+row, DO storage/requests, sandbox windows, keep-warm uptime, Workflows/D1/KV/Artifacts).
B. Attribution: the boundary stamps keySource + per-key-owner rows (already exist); sandbox
windows/sessions attribution (per session? per team?).
C. Settle-time legs: platform cost = rates x OUR measured counts appended to turn records (the
drawer's cost = model + platform) — which counters are measurable in-worker (tokens, DO storage
via databaseSize, per-gen, isolate starts) vs rates-only (CPU-ms, R2 usage, duration, egress).
D. Rate card + markup policy (fungi x1.25 exists; platform-leg markup? per-door pricing?).
E. Billable-Usage reconciliation: cadence, drift ownership, the free-tier posture per door.
F. The always-on tier: mechanism + price (keep-warm = billable; also projects keep-warm?).

## Constraints

READ-ONLY. Deliverables = FILES plans/meter-kings/{minimalist,native,standard-bearer}.md
(<=140 lines). One-line finals. Timebox 40 min. Human rules the forks. The 3 doors are LAW;
the kill list is LAW (projects = dynamic workers only).

## POST-COUNCIL RULING (Levi, 2026-08-22) - keep-warm = no special code

- Containers bill their UPTIME at the per-10ms rate, platform-side, automatically. No keep-warm
  detection/policing code exists or should exist for users. The meter's only job: ATTRIBUTE the
  container window (which key-owner) + SURFACE it as the always-on tier's bill line
  (warmWindowMs = attribution + the line, not detection).
- The wedge-law discipline is RETIRED for users (surfacing only); it survives solely as internal
  hygiene (our own accidentals never ride the account free). The kill list removed the class that
  made policing matter.
