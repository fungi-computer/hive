# @fungi.computer/watchdog

`@fungi.computer/watchdog` is Runtime Core's payload-blind durable job engine.
It owns each bounded job's owner-local SQLite row and lifecycle. The host
supplies a structural SQLite owner, execution, liveness, and wake capabilities;
it does not implement Watchdog's state machine. Watchdog treats the payload,
queue, and lane as opaque values supplied by the caller.

The Effect runtime and Promise facade expose five operations:

- `ingest` and `read` accept or inspect one durable job;
- `tick` performs one bounded selection, private claim, execution, and exact
  settlement; a concurrent tick reports `busy`;
- `cancel` records durable cancellation before signalling a live execution; and
- `purge` removes queued jobs for one queue.

Construction also returns one synchronous `transactional` projection so an
enclosing owner transaction can enqueue accepted work or record cancellation. It
uses the same private mutation as normal `ingest` and `cancel`; no SQL or claim
operation crosses that seam.

Each runtime has a cohesive recovery capability. A tick recovers work only after
the owner probe proves the prior execution disappeared; an unanswered probe
leaves the claim untouched. Claim tokens, SQLite rows, and claim/settle
machinery remain private. Watchdog does not interpret payloads or own
domain-specific queue/lane vocabulary.

## License

MIT. See [LICENSE](./LICENSE).
