# @fungi.computer/mule

Mule runs Pi's model-and-tool loop inside Effect. Pi owns models, messages,
provider replay fields, tool declarations, and streaming events. Mule does not
translate or reconstruct those values.

Mule adds only process-local orchestration:

- an interruptible Effect scope around each Pi stream;
- awaited run, turn, message, and tool lifecycle events;
- Effect-native tool preparation and execution;
- Pi's steering, follow-up, tool ordering, and truncated-call behavior; and
- stable causal identities for the emitted lifecycle.

Mule owns no Session storage, model catalog, credentials, provider retry,
compaction, or durable work recovery.

## Run any Pi model

Supply a normal Pi `Model<Api>`. Mule uses Pi's `streamSimple` by default. An
explicit Pi provider stream can be injected for the newer provider runtime or
for tests. The transcript and returned messages remain Pi `Message` values.

```ts
import type { Api, Model } from "@earendil-works/pi-ai";
import { mule } from "@fungi.computer/mule";

declare const model: Model<Api>;

const outcome = await mule.run(
  {
    model,
    systemPrompt: "Answer concisely.",
    messages: [
      { role: "user", content: "How are you?", timestamp: Date.now() },
    ],
  },
  async (event) => {
    if (event.type === "message_update" && event.event.type === "text_delta") {
      process.stdout.write(event.event.delta);
    }
  },
);
```

The canonical interface is `@fungi.computer/mule/effect`. The package root is
one Promise facade that lifts the listener once and runs that same Effect
program once.

## Camel smoke test

The repository CLI represents camelStream exactly as its documented Pi custom
model: the `openai-responses` API at `https://stream.camelai.com/v1`.

```sh
export CAMEL_API_KEY="qaml_live_..."
pnpm --silent mule:prompt -- "How are you?"
```

`CAMEL_API_URL` and `CAMEL_MODEL` may override the documented endpoint and
`auto` model id for local verification. They do not change Mule itself.
