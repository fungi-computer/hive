# @fungi.computer/mycelium

Mycelium is Fungi's scoped capability lifecycle. Capability authors define
bounded inner operations with Zod; Mycelium prepares one immutable Forage
catalog and presents the installed graph to Mule as one top-level `execute`
tool. The lifecycle implementation is Effect-native, while the default facade
and host adapters remain Promise-shaped.

## Define a capability graph

```ts
import { Mycelium, type Sandbox } from "@fungi.computer/mycelium";
import { z } from "zod";

const notes = Mycelium.module({
  id: "notes-v1",
  name: "notes",
  description: "Read bounded notes",
  operations: {
    read: Mycelium.operation({
      input: z.object({ path: z.string().min(1).max(4_096) }),
      output: z.object({ text: z.string().max(64 * 1_024) }),
      execute: async ({ path }, context) => {
        if (context.signal.aborted) throw context.signal.reason;
        return { text: `Contents of ${path}` };
      },
    }),
  },
});

declare const sandbox: Sandbox;

const runtime = await Mycelium.make({ modules: [notes], sandbox });
const lease = await runtime.acquire();

try {
  lease.catalog.search({ query: "notes" });
  // Supply lease.executeTool to Mule for this run.
} finally {
  await lease.release();
  await runtime.close();
}
```

Mule sees only `execute`. The `notes.read`, `forage.search`, and
`forage.describe` operations remain behind that door. Stable module IDs decide
authority identity; friendly names become deterministic model-facing aliases.
Input order never decides either one.

## Project changing host capabilities

Use `sources` when a host must acquire a current Computer, Connection, App, or
other capability projection. A source returns one bounded snapshot and one
awaited release function. Its payload-free `invalidate()` callback marks that
snapshot stale; the next lease rebuilds coherently while existing leases keep
their captured graph.

Mycelium does not store relationships, subscribe to a generic event bus, or
retain credentials. The host owns durable membership and policy. Final-egress
adapters must recheck current authority before external work.

## Execution and lifecycle laws

- Every runtime has a deadline and cancellation-acknowledgement grace. The
  defaults are 180 seconds and 5 seconds.
- A successful sandbox value must be JSON and its one canonical UTF-8 encoding
  must not exceed 256 KiB.
- Cancellation aborts the invocation signal and waits up to the configured
  acknowledgement grace for actual sandbox settlement. A Promise that ignores
  abort fails as `abort_unacknowledged`; it cannot be reported as stopped.
- A lease is immutable. Partial acquisition rolls back in reverse order, and
  every acquired source is released exactly once.
- `@fungi.computer/mycelium/effect` exposes the canonical scoped Effect API. The
  root entry point is the Promise-shaped adapter for ordinary hosts.

Concrete Computer, Files, browser, Whistle, MCP, OpenAPI, Connection, App,
credential, and product relationship adapters are deliberately outside this
package. They contribute typed modules or capability sources without becoming
Mycelium concerns.

## License

MIT. See [LICENSE](./LICENSE) and [THIRD_PARTY_NOTICES](./THIRD_PARTY_NOTICES).
