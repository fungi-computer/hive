# @fungi.computer/forage

Pure, immutable, bounded capability discovery. Forage accepts a provisioned
catalog of Zod 4 operations and exposes deterministic `search` and `describe`
methods. It carries no executors, credentials, authorization state, or host
clients, and depends only on Zod; Mycelium owns execution and lifecycle. This
package proves no Mycelium or Shiitake integration.

```ts
import { Forage } from "@fungi.computer/forage";
import { z } from "zod";

const catalog = Forage.createCatalog({
  revision: "run-1",
  operations: [
    {
      path: "files.read",
      description: "Read a file",
      input: z.object({ path: z.string() }),
    },
  ],
});
catalog.search({ query: "read" });
catalog.describe({ path: "files.read" });
```

The API and inferred types are intentionally small and stable. A new provisioned
surface creates a new catalog rather than mutating an existing one.

`catalog.stamp()` hashes sorted `(namespace, method, description)` triples.
Schema shape, capability notes, and instructions intentionally do not change
that stamp; instructions remain module-description guidance.

## Source and behavior attribution

Forage independently re-expresses selected MIT-licensed Cloudflare Codemode
discovery behavior. It preserves the bounded S1–S9 discovery laws without
including an executable connector, mutable refresh, handwritten JSON Schema,
snippets, or skills contracts. See [THIRD_PARTY_NOTICES](./THIRD_PARTY_NOTICES)
for the required attribution.

## License

MIT. See [LICENSE](./LICENSE) and [THIRD_PARTY_NOTICES](./THIRD_PARTY_NOTICES).
